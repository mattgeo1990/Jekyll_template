---
title: "Research"
permalink: /research/
---

## Research

Details about current and past research projects will go here.
