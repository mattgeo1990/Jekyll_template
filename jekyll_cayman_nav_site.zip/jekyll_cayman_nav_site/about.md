---
title: "About"
permalink: /about/
---

## About Me

I’m a National Science Foundation Postdoctoral Fellow at the University of Michigan.  
My research combines geochemistry, paleontology, and stratigraphy to reconstruct ancient environments and climate.

Outside of academia, I enjoy trail running, fly fishing, and spending time with my family.
