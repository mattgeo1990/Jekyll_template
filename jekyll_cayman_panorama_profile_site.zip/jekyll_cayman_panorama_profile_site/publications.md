---
title: "Publications"
permalink: /publications/
---

## Publications

You can view my publications on [Google Scholar](https://scholar.google.com).
