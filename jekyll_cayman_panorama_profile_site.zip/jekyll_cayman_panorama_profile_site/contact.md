---
title: "Contact"
permalink: /contact/
---

## Contact

You can reach me via email at:  
**mattall [at] umich [dot] edu**
