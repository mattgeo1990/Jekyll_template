---
title: "About"
permalink: /about/
---

## About Me

I’m a National Science Foundation Postdoctoral Fellow at the University of Michigan.
